#include "environment.h"
#include <QPainter>
#include <QRandomGenerator>
Environment::Environment(QWidget *parent) : QWidget(parent)
{
    layoutInit();//界面初始化
    // this->setAttribute(Qt::WA_DeleteOnClose,false);//关闭界面，不释放资源
}


void Environment::layoutInit()
{
    this->setStyleSheet("background-color:#000000");
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->showFullScreen();

    exitPushButton= new QPushButton("返 回",this);
    exitPushButton->setGeometry(1550,50,300,100);
    exitPushButton->show();
    exitPushButton->setStyleSheet("color:black;border-radius:15px;font-size:60px;font-weight:bold;background-color:white");

    connect(exitPushButton,&QPushButton::clicked,this,[=](){
        this->hide();
    });

    title = new QLabel(this);
    title->setText("温湿度实时监控");
    title->setGeometry(400,50,800,100);
    title->show();
    title->setStyleSheet("color:white;font-size:100px;letter-spacing:5px;font-weight:bold;");


    /*显示温度湿度曲线*/


    // timer = new QTimer(this);
    // connect(timer, SIGNAL(timeout()), this, SLOT(updateTemp()));

    TempChart();
}

void Environment::TempChart()
{

    chartWidget = new QWidget(this);
    chartWidget->setGeometry(0,200,2000,1000);
    // chartWidget->setStyleSheet("font-size:1000px;");
    chartWidget->show();

    QChart *chart = new QChart();
    chartview = new QChartView(chart,chartWidget);
    chart->setTitle("温度(°C)/湿度(%)");/*设置图例标题*/
    chartview->resize(chartWidget->size());
    chartview->setRenderHint(QPainter::Antialiasing, true);/*抗锯齿*/
    chartview->setChart(chart);
    // chartview->setStyleSheet("font-size:100px;background-color:black");
    chart->setBackgroundBrush(QBrush(QColor("#000000")));

    /*x轴*/
    ax = new QDateTimeAxis();
    ax->setTitleText("times");
    ax->setTickCount(15);
    ax->setLineVisible(true);
    ax->setGridLineVisible(true);
    ax->setFormat("hh:mm:ss");
    ax->setRange(QDateTime::currentDateTime(), QDateTime::currentDateTime().addSecs(15));

    /*y轴*/
    QValueAxis *ay = new QValueAxis();
    ay->setTitleText("template/humidity");
    ay->setTickCount(15);
    ay->setLabelFormat("%.1f");//让y轴显示出小数部分
    ay->setRange(0, 100);
    ay->setLineVisible(true);
    ay->setGridLineVisible(true);

    // chart->zoom(0.5);

    chartview->show();
    chart->show();


    /*温度曲线*/
    temp_series = new QLineSeries();
    temp_series->setName("温度");
    temp_series->setColor(QColor(255, 200, 20));
    /*设置初始值*/
    temp_series->append(QDateTime::currentDateTime().toMSecsSinceEpoch(), 30);

    /*湿度曲线*/
    hum_series = new QLineSeries();
    hum_series->setName("湿度");
    hum_series->setColor(QColor(150, 100, 200));
    /*设置初始值*/
    hum_series->append(QDateTime::currentDateTime().toMSecsSinceEpoch(), 50);

    /*将温度曲线添加进chart*/
    chart->addSeries(temp_series);
    chart->setAxisX(ax, temp_series);
    chart->setAxisY(ay, temp_series);

    /*将湿度曲线添加进chart*/
    chart->addSeries(hum_series);
    chart->setAxisX(ax, hum_series);
    chart->setAxisY(ay, hum_series);

    //chart->legend()->hide();//隐藏图标
}


void Environment::updateTemp()
{
    // 更新温度曲线数据
    qint64 timestamp = QDateTime::currentDateTime().toMSecsSinceEpoch();
    double temperature = (double)(rand() % 30);

    // 更新湿度数据
    double hum = (double)(rand() % 100);

    /*显示当前温度和湿度*/
    QString TempHum = QString("当前温度:") +QString::number(temperature, 'f', 1) + "°C"
                      + QString("当前湿度:") + QString::number(hum, 'f', 1) + "%";

    TempHumlbl->setText(TempHum);

    /*添加当前时间点的温度和湿度*/
    if (temp_series != nullptr && hum_series != nullptr)
    {
        temp_series->append(timestamp, temperature);
        hum_series->append(timestamp, hum);
        qDebug() << temp_series->count();
        if (temp_series->count() > 16)
        {
            /*移除第一个点*/
            temp_series->removePoints(0, 1);

            hum_series->removePoints(0, 1);

        }

        qDebug() << temp_series->count();

        // 调整温度曲线的 x 轴范围
        if (temp_series->count() > 15)
        {
            ax->setRange(QDateTime::fromMSecsSinceEpoch(temp_series->at(0).x()),
                         QDateTime::fromMSecsSinceEpoch(temp_series->at(temp_series->count()-1).x()));
        }
    }
}

