#include "Mainwidget.h"
#include <QGuiApplication>
#include <QScreen>
#include <QDebug>



Widget::Widget(QWidget *parent)
    : QWidget(parent)
{

    this->setStyleSheet("background-color:rgb(30,41,61)");

    layoutInit();//初始化界面

    // //创建子线程
    // subThread= new QThread;

    // // 千万不要指定给创建的任务对象指定父对象
    // // 如果指定了: QObject::moveToThread: Cannot move objects with a parent
    // messageBoard = new MessageBoard;

    // //将任务对象移动到子线程中
    // messageBoard->moveToThread(subThread);
    // //启动子线程
    // subThread->start();
    // connect(subThread, &QThread::started, messageBoard, &MessageBoard::working);//子线程开启后，自动执行working()函数
    // connect(subThread,&QThread::finished,messageBoard,&QObject::deleteLater);//释放getSensorDataBySerialTask对象空间
    // connect(subThread,&QThread::finished,subThread,&QObject::deleteLater);//释放subThread对象空间
    // connect(messageBoard,&MessageBoard::finished,subThread,&QThread::quit);
    // connect(messageBoard,&MessageBoard::getMqttMessage,messageBoard_content,[=](QByteArray message){
    //     messageBoard_content->setText(QString(message));
    // });

}

void Widget::layoutInit()
{
    /******************界面时钟功能**********************/
    clock_timer = new QTimer(this);//创建一个定时器对象
    time_QLabel = new QLabel(this);//显示标签
    ampm_QLabel = new QLabel(this);//显示上下午标签
    line_QLabel = new QLabel(this);//显示横线的标签
    date_QLabel = new QLabel(this);//显示日期的标签

    clock_timer->start(1000);//开启时钟定时

    connect(clock_timer,&QTimer::timeout,time_QLabel,[=](){//定时器发出timeout信号
        currentDateTime = QDateTime::currentDateTime();
        // qDebug()<<QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz dddd");
        time_QLabel->setText(currentDateTime.toString("hh:mm"));
        ampm_QLabel->setText(currentDateTime.toString("A"));
        date_QLabel->setText(currentDateTime.toString("yyyy 年 MM 月 dd 日"));
        line_QLabel->setText("————————");
    });


    time_QLabel->setGeometry(100,100,350,100);
    time_QLabel->setStyleSheet("font-size:120px;color:white");

    ampm_QLabel->setAlignment(Qt::AlignCenter);
    ampm_QLabel->setGeometry(450,100,200,100);
    ampm_QLabel->setStyleSheet("font-size:100px;color:white");

    line_QLabel->setAlignment(Qt::AlignCenter);
    line_QLabel->setGeometry(100,220,510,2);
    line_QLabel->setStyleSheet("border: 5px solid;border-color:white;font-size:20px;color:white");

    date_QLabel->setAlignment(Qt::AlignCenter);
    date_QLabel->setGeometry(100,250,500,45);
    date_QLabel->setStyleSheet("font-size:50px;color:white");


    /********************天气界面***********************/
    weather_cityName_QLabel = new QLabel("位置",this);//显示城市名称
    weather_cityName_QLabel->setGeometry(100,380,200,95);
    weather_cityName_QLabel->setAlignment(Qt::AlignCenter);
    weather_cityName_QLabel->setStyleSheet("font-size:100px;color:white");
    weather_cityName_QLabel->installEventFilter(this);//给控件安装事件过滤器,给标签增加点击功能

    weather_temperature_QLabel = new QLabel("℃",this);//显示城市天气温度
    weather_temperature_QLabel->setGeometry(100,500,200,95);
    weather_temperature_QLabel->setAlignment(Qt::AlignCenter);
    weather_temperature_QLabel->setStyleSheet("font-size:100px;color:white");
    weather_temperature_QLabel->installEventFilter(this);

    weather_image_QLabel = new QLabel(this);//显示天气状态图片
    weather_image_QLabel->setGeometry(350,365,150,150);
    weather_image_QLabel->setAlignment(Qt::AlignCenter);
    weather_image_QLabel->setStyleSheet("border-image:url("":/image_wea/image/refresh.png"")");
    weather_image_QLabel->installEventFilter(this);

    weather_imageName_QLabel = new QLabel("点击刷新",this);//显示天气状态文字
    weather_imageName_QLabel->setGeometry(330,520,190,100);
    weather_imageName_QLabel->setAlignment(Qt::AlignCenter);
    weather_imageName_QLabel->setStyleSheet("font-size:50px;color:white");
    weather_imageName_QLabel->installEventFilter(this);

    weatherInfoThread = new QThread;//获取天气信息的子线程
    weatherInfo = new WeatherInfo;//创建天气信息对象
    weatherInfo->moveToThread(weatherInfoThread);//对象移动到线程中
    weatherInfoThread->start();//启动线程，但是不会执行获取天气函数，需要通过信号触发getWeatherInfo

    connect(weatherInfoThread, &QThread::finished, weatherInfoThread, &QObject::deleteLater);
    connect(weatherInfoThread,&QThread::started,weatherInfo,&WeatherInfo::getWeatherInfo);

    connect(weatherInfo,&WeatherInfo::updateWeather,this,[=](QString cityName,QString cityTemperture,QString weatherImagePath,QString weatherStatus){
        weather_cityName_QLabel->setText(cityName);
        weather_temperature_QLabel->setText(cityTemperture);
        weather_imageName_QLabel->setText(weatherStatus);
        weather_image_QLabel->setStyleSheet(weatherImagePath);
    });


    // /**************************留言板界面********************************/
    // messageBoard_Title = new QLabel("留　言　板",this);
    // messageBoard_Title->setGeometry(10,260,210,30);
    // messageBoard_Title->setAlignment(Qt::AlignCenter);
    // messageBoard_Title->setStyleSheet("border: 1px solid;border-color:white;font-size:22px;color:white");

    // messageBoard_content = new QLabel(this);
    // messageBoard_content->setGeometry(10,290,210,180);
    // messageBoard_content->setAlignment(Qt::AlignVCenter);
    // messageBoard_content->setWordWrap(true);
    // messageBoard_content->setMargin(5);
    // messageBoard_content->setStyleSheet("border: 1px solid;border-color:white;font-size:16px;color:white");
    // messageBoard_content->installEventFilter(this);

    // /**************************app界面****************************/
    // appWidget = new QWidget(this);//右边主窗口
    // appWidget->setGeometry(230,0,570,480);

    // mySlidePage = new SlidePage(appWidget);//创建滑动页面
    // mySlidePage->resize(appWidget->size());//自适应右边窗口

    // appPageOne = new App(appWidget);//创建第一个app页面
    // // appPageTwo = new App2(appWidget);//创建第二个app页面

    // mySlidePage->addPage(appPageOne);//添加到滑动页面
    // // mySlidePage->addPage(appPageTwo);//添加到滑动页面
}


/**************************事件过滤******************************/

bool Widget::eventFilter(QObject * watched, QEvent * event)
{
   if (watched == weather_cityName_QLabel||watched == weather_temperature_QLabel||watched == weather_image_QLabel||watched == weather_imageName_QLabel)
   {
       if (event->type() == QEvent::MouseButtonPress)
       {
           QMetaObject::invokeMethod(weatherInfo, "getWeatherInfo", Qt::QueuedConnection);
       }
   }
    // if(watched == messageBoard_content)
    // {
    //     if(event->type() == QEvent::MouseButtonPress)
    //     {
    //         messageBoard_content->setText("");
    //         //调用语音助手
    //     }
    // }
    return false;//处理完事件后，不需要事件继续传播
    //return SmartGateway::eventFilter(watched, event);//继续传播，如果注释上一行，程序不能运行
}

// void SmartGateway::resizeEvent(QResizeEvent *event)
// {
//     Q_UNUSED(event)
//     mySlidePage->resize(appWidget->size());
// }



Widget::~Widget() {}
